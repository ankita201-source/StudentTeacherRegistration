package com.registration;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class RegistrationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String type = request.getParameter("type"); // student or teacher

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
            	    "jdbc:mysql://localhost:3306/registrationdb", "root", "YOUR_PASSWORD");

            if ("student".equalsIgnoreCase(type)) {
                // Student registration
                String name = request.getParameter("name");
                String age = request.getParameter("age");
                String course = request.getParameter("course");
                String location = request.getParameter("location");
                String qualification = request.getParameter("qualification");

                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO student_(name, age, course, location, qualification) VALUES (?,?,?,?,?)");
                ps.setString(1, name);
                ps.setString(2, age);
                ps.setString(3, course);
                ps.setString(4, location);
                ps.setString(5, qualification);
                ps.executeUpdate();
                out.println("<h3>Student Registration Successful!</h3>");

            } else if ("teacher".equalsIgnoreCase(type)) {
                // Teacher registration
                String name = request.getParameter("name");
                String age = request.getParameter("age");
                String salary = request.getParameter("salary");
                String experience = request.getParameter("experience");
                String specialization = request.getParameter("specialization");
                String project = request.getParameter("project");

                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO teacher_(name, age, salary, experience, specialization, project) VALUES (?,?,?,?,?,?)");
                ps.setString(1, name);
                ps.setString(2, age);
                ps.setString(3, salary);
                ps.setString(4, experience);
                ps.setString(5, specialization);
                ps.setString(6, project);
                ps.executeUpdate();
                out.println("<h3>Teacher Registration Successful!</h3>");
            } else {
                out.println("<h3>Invalid form type!</h3>");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }
}
