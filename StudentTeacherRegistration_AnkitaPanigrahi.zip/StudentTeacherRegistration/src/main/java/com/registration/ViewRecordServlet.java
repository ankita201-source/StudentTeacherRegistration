package com.registration;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class ViewRecordServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>All Records</title>");
        out.println("<style>");
        out.println("body { font-family: Arial; background-color: #f0f2f5; padding: 20px; }");
        out.println("h2 { color: #333; }");
        out.println("table { border-collapse: collapse; width: 80%; margin-bottom: 40px; background: white; }");
        out.println("th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }");
        out.println("th { background-color: #4CAF50; color: white; }");
        out.println("</style></head><body>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/registrationdb", "root", "YOUR_PASSWORD");

            // === STUDENTS TABLE ===
            out.println("<h2>Student Records</h2>");
            PreparedStatement ps1 = con.prepareStatement("SELECT * FROM student_");
            ResultSet rs1 = ps1.executeQuery();

            out.println("<table>");
            out.println("<tr><th>ID</th><th>Name</th><th>Age</th><th>Course</th><th>Location</th><th>Qualification</th></tr>");
            while (rs1.next()) {
                out.println("<tr>");
                out.println("<td>" + rs1.getInt("id") + "</td>");
                out.println("<td>" + rs1.getString("name") + "</td>");
                out.println("<td>" + rs1.getString("age") + "</td>");
                out.println("<td>" + rs1.getString("course") + "</td>");
                out.println("<td>" + rs1.getString("location") + "</td>");
                out.println("<td>" + rs1.getString("qualification") + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");

            // === TEACHERS TABLE ===
            out.println("<h2>Teacher Records</h2>");
            PreparedStatement ps2 = con.prepareStatement("SELECT * FROM teacher_");
            ResultSet rs2 = ps2.executeQuery();

            out.println("<table>");
            out.println("<tr><th>ID</th><th>Name</th><th>Age</th><th>Salary</th><th>Experience</th><th>Specialization</th><th>Project</th></tr>");
            while (rs2.next()) {
                out.println("<tr>");
                out.println("<td>" + rs2.getInt("id") + "</td>");
                out.println("<td>" + rs2.getString("name") + "</td>");
                out.println("<td>" + rs2.getString("age") + "</td>");
                out.println("<td>" + rs2.getString("salary") + "</td>");
                out.println("<td>" + rs2.getString("experience") + "</td>");
                out.println("<td>" + rs2.getString("specialization") + "</td>");
                out.println("<td>" + rs2.getString("project") + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");

            con.close();

        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
            e.printStackTrace(out);
        }

        out.println("</body></html>");
    }
}
